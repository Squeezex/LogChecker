The script searches the specified words that don't exist in the logs and puts them into a separate folder by match.
The script prints list of correct or broken files
it can be customised (WIP)