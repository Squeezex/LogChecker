The script searches the specified words that don't exist in the logs and copy them into a separate folder by match.
The script do debug print of created folder and copied broken files
it can be customised (WIP)